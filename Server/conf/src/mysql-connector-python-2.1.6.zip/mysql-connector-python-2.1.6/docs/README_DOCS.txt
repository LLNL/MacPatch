The manual of MySQL Connector/Python is available online here:

 http://dev.mysql.com/doc/connector-python/en/index.html


It is also available for download in various formats here:

 http://dev.mysql.com/doc/index-connectors.html

