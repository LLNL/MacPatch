
local s = require 'string'

function handle_simple(r)
  -- r:addoutputfilter("wombathood")
  r:puts("added wombathood")
end